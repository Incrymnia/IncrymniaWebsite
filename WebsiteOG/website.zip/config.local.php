<?php
/**
 * Copy this file to config.local.php and fill in the two SMTP values.
 * config.local.php is private: it is blocked by .htaccess and listed in .gitignore.
 *
 * How to get a Gmail App Password (about 2 minutes):
 *   1. Sign in to the Gmail account that will SEND the emails (incrymniapc@gmail.com).
 *   2. Turn on 2-Step Verification: https://myaccount.google.com/security
 *   3. Open https://myaccount.google.com/apppasswords
 *   4. Create an app password (name it "Website"). Google shows 16 letters.
 *   5. Paste them below. Spaces are fine, they are removed automatically.
 *
 * Your normal Gmail password will NOT work here.
 */

declare(strict_types=1);

return [
    'smtp' => [
        'username' => 'incrymniapc@gmail.com',
        'password' => 'nzuz heel oumc fbos',   // REPLACE with your 16-character App Password
    ],
];